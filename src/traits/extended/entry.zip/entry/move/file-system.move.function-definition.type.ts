import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export type IFileSystemMoveFunctionNotifications = IDefaultNotificationsUnion<URL>;

/**
 * Moves source to destination. Returns destination.
 */

export interface IFileSystemMoveFunction {
  (
    source: URL,
    destination: URL,
  ): IObservable<IFileSystemMoveFunctionNotifications>;
}

