import { IFileSystemMoveFunction } from './file-system.move.function-definition.type';

export interface IFileSystemMoveTraitCollection {
  move: IFileSystemMoveFunction;
}
