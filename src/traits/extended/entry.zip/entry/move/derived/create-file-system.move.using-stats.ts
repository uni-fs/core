import { combineLatestSpread, IObservable } from '@lirx/core';
import { IFileSystemMoveFunction, IFileSystemMoveFunctionNotifications } from '../file-system.move.function-definition.type';


combineLatestSpread()
export function createFileSystemMoveUsingStats(
  // stats: IFileSystemStatsFunction,
): IFileSystemMoveFunction {
  return (
    url: URL,
  ): IObservable<IFileSystemMoveFunctionNotifications> => {
    throw 'TODO'; // TODO
    // return stats(url)
    //   .then(() => true, () => false); // TODO improve the catch !
  };
}

