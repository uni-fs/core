import { IFileSystemExistsTraitCollection } from './exists/file-system.exists.trait.type';

export interface IFileSystemExtendedEntryTraitCollection extends //
  // IFileSystemCopyTraitCollection,
  IFileSystemExistsTraitCollection
//
{
}

