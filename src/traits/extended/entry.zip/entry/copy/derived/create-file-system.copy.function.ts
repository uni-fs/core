import { IFileSystemCopyFunction, IFileSystemCopyFunctionNotifications } from '../file-system.copy.function-definition.type';

import { IFileSystemTypes } from '../../../../shared/file-system.types.type';
import { IFileSystemTypesFunction } from '../../../../core/entry/types/file-system.types.function.type';
import { IFileSystemChildrenFunction } from '../../../../core/directory/children/file-system.children.function.type';
import { cloneURL } from '../../../../../../../shared/helpers/clone-url';
import { IFileSystemSizeFunction } from '../../../file/size/file-system.size.function.type';
import {
  IFileSystemReadFunction, IFileSystemReadFunctionNotifications,
} from '../../../../core/file/read/file-system.read.function.type';
import { getOptimalBufferSize } from '../../../../../../../shared/helpers/get-optimal-buffer-size';
import {
  IFileSystemWriteFunction, IFileSystemWriteFunctionNotifications, IFileSystemWriteOptions,
} from '../../../../core/file/write/file-system.write.function.type';
import { fulfilled$$$, IDefaultNotificationsUnion, IObservable, pipe$$, throwError } from '@lirx/core';


export interface ICreateFileSystemCopyOptions extends Omit<IFileSystemCopyOptions, 'sourceURL' | 'destinationURL'> {
}

export function createFileSystemCopyFunction(
  _options: ICreateFileSystemCopyOptions,
): IFileSystemCopyFunction {
  return (
    sourceURL: URL,
    destinationURL: URL,
  ): IObservable<IFileSystemCopyFunctionNotifications> => {
    return fileSystemCopy({
      ..._options,
      sourceURL,
      destinationURL,
    });
  };
}

export interface IFileSystemCopyOptions extends IFileSystemCopyFileOptions {
  sourceTypesFunction: IFileSystemTypesFunction;
  sourceChildrenFunction: IFileSystemChildrenFunction;
}


export function fileSystemCopy(
  options: IFileSystemCopyOptions,
): IObservable<IFileSystemCopyFunctionNotifications> {
  return pipe$$(options.sourceTypesFunction(options.sourceURL), [
    fulfilled$$$((types: Set<IFileSystemTypes>): IObservable<IFileSystemCopyFunctionNotifications> => {
      if (types.has('file')) {
        return fileSystemCopyFile(options);
      } else if (types.has('directory') || types.has('root')) {
        return fileSystemCopyDirectory(options);
      } else {
        return throwError(new Error(`Unsupported type for copy`));
      }
    })
  ]);
}

/** FILE_SYSTEM_COPY_DIRECTORY **/

/**
 * Copies a directory recursively, and returns
 */
export function fileSystemCopyDirectory(
  options: IFileSystemCopyOptions,
): IObservable<IFileSystemCopyFunctionNotifications> {
  throw 'TODO';
  // return pipe$$(options.sourceChildrenFunction(options.sourceURL), [
  //
  // ]);
  // const iterator: AsyncGenerator<URL, void, void> = options.sourceChildrenFunction(options.sourceURL);
  // let result: IteratorResult<URL>;
  // while (!(result = await iterator.next()).done) {
  //   // TODO: use URLToPath and/or URLConcatPath instead
  //   const parts: string[] = result.value.pathname.split('/');
  //
  //   if (parts.length > 0) {
  //     const destinationChildURL: URL = cloneURL(options.destinationURL);
  //     destinationChildURL.pathname += (destinationChildURL.pathname.endsWith('/') ? '' : '/') + parts[parts.length - 1];
  //     await fileSystemCopy(options);
  //   } else {
  //     throw new Error(`Expected children with a valid name`);
  //   }
  // }
  //
  // return options.destinationURL;
}

/** FILE_SYSTEM_COPY_FILE **/

export interface IFileSystemCopyFileOptions extends IFileSystemCopyFileByChunkOptions {
}

/**
 * Copies an entire file
 */
export function fileSystemCopyFile(
  options: IFileSystemCopyFileOptions,
): IObservable<IFileSystemCopyFunctionNotifications> {
  const iterator: AsyncGenerator<IProgress, void, void> = fileSystemCopyFileByChunk(options);
  let result: IteratorResult<IProgress>;
  while (!(result = await iterator.next()).done) {
  }
  return options.destinationURL;
}


/** FILE_SYSTEM_COPY_FILE_BY_CHUNK **/

export interface IFileSystemCopyFileByChunkOptions extends Omit<IFileSystemCopyFileChunkOptions, 'buffer' | 'writeOptions'> {
  // sourceSizeFunction?: IFileSystemSizeFunction | undefined;
}

/**
 * Splits the copy of a file in chunks, using an optimal chunk's size based on available memory.
 * This allows the copy of massive file, like if it was a stream
 */
export function fileSystemCopyFileByChunk(
  options: IFileSystemCopyFileByChunkOptions,
): IObservable<any> {

  const copyFileChunk = (start: number) => {
    return pipe$$(fileSystemCopyFileChunk({
      ...options,
      writeOptions: {
        start,
      }
    }), [
      fulfilled$$$((size: number): IObservable<IFileSystemWriteFunctionNotifications> => {
        return destinationWriteFunction(destinationURL, buffer, writeOptions);
      }),
    ]);
  };



  const read$ = sourceReadFunction(sourceURL, new Uint8Array(getOptimalBufferSize()));
  const write$ = destinationWriteFunction(destinationURL, {
    start: 0,
    truncateMode: 'clear',
  });

  // const total: number = (sourceSizeFunction === void 0)
  //   ? Number.POSITIVE_INFINITY
  //   : await sourceSizeFunction(sourceURL);
  //
  // const readIterator: IObservable<IFileSystemReadFunctionNotifications> = sourceReadFunction(sourceURL, new Uint8Array(getOptimalBufferSize()));
  // const writeIterator: AsyncGenerator<number, void, Uint8Array | null> = destinationWriteFunction(destinationURL, {
  //   position: 0,
  //   truncateMode: 'clear',
  // });
  //
  // let readResult: IteratorResult<Uint8Array>;
  // let writeResult: IteratorResult<number>;
  // let buffer: Uint8Array | null = null;
  // while (true) {
  //   // reading current chunk while writing previous one
  //   [readResult, writeResult] = await Promise.all([
  //     readIterator.next(),
  //     writeIterator.next(buffer), // first value is set to null for init
  //   ]);
  //
  //   if (!writeResult.done) {
  //     yield {
  //       loaded: writeResult.value,
  //       total,
  //     };
  //   }
  //
  //   if (readResult.done) {
  //     await writeIterator.next(null);
  //     return;
  //   } else {
  //     buffer = readResult.value.slice(); // do a copy, else buffer will be erased while reading
  //   }
  // }
}



export interface IFileSystemCopyFileChunkOptions {
  sourceReadFunction: IFileSystemReadFunction;
  destinationWriteFunction: IFileSystemWriteFunction;
  sourceURL: URL;
  destinationURL: URL;
  buffer?: Uint8Array;
  writeOptions?: IFileSystemWriteOptions;
}

/**
 * Copy a portion of a File
 */
export function fileSystemCopyFileChunk(
  {
    sourceReadFunction,
    destinationWriteFunction,
    buffer = new Uint8Array(getOptimalBufferSize()),
    writeOptions,
    sourceURL,
    destinationURL,
  }: IFileSystemCopyFileChunkOptions,
): IObservable<IFileSystemWriteFunctionNotifications> {
  return pipe$$(sourceReadFunction(sourceURL, buffer), [
    fulfilled$$$((buffer: Uint8Array): IObservable<IFileSystemWriteFunctionNotifications> => {
      return destinationWriteFunction(destinationURL, buffer, writeOptions);
    }),
  ]);
}
