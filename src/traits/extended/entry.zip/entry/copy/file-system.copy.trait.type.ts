import { IFileSystemCopyFunction } from './file-system.copy.function-definition.type';

export interface IFileSystemCopyTraitCollection {
  copy: IFileSystemCopyFunction;
}
