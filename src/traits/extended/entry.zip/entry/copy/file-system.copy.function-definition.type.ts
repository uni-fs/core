import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export type IFileSystemCopyFunctionNotifications = IDefaultNotificationsUnion<URL>;

/**
 * Copies source to destination. Returns destination.
 */

export interface IFileSystemCopyFunction {
  (
    source: URL,
    destination: URL,
  ): IObservable<IFileSystemCopyFunctionNotifications>;
}

