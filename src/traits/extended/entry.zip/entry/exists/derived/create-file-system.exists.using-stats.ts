import {
  IFileSystemExistsFunctionNotifications, IFileSystemExistsFunction,
} from '../file-system.exists.function-definition.type';

import { IFileSystemStatsFunction } from '../../../../core/entry/stats/file-system.stats.function-definition';
import { IObservable, pipe$$, singleN, then$$$ } from '@lirx/core';


export function createFileSystemExistsUsingStats(
  stats: IFileSystemStatsFunction,
): IFileSystemExistsFunction {
  return (
    url: URL,
  ): IObservable<IFileSystemExistsFunctionNotifications> => {
    return fileSystemExistsUsingStats(
      stats,
      url,
    );
  };
}

export function fileSystemExistsUsingStats(
  stats: IFileSystemStatsFunction,
  url: URL,
): IObservable<IFileSystemExistsFunctionNotifications> {
  return pipe$$(stats(url), [
    then$$$(
      () => singleN(true),
      () => singleN(true),
    ), // TODO improve the catch !
  ]);
}

