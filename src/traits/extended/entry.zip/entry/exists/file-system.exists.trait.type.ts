import { IFileSystemExistsFunction } from './file-system.exists.function-definition.type';

export interface IFileSystemExistsTraitCollection {
  exists: IFileSystemExistsFunction;
}
