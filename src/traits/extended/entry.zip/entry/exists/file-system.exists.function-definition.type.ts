import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export type IFileSystemExistsFunctionNotifications = IDefaultNotificationsUnion<boolean>;

/**
 * Returns true if the entry exists
 */
export interface IFileSystemExistsFunction {
  (
    url: URL,
  ): IObservable<IFileSystemExistsFunctionNotifications>;
}

