import { IFileSystemMetadata } from '../../../core/entry/metadata/file-system-metadata.type';
import { IFileSystemChildrenWithMetadataFunction } from './file-system.children-with-metadata.function-definition';

export interface IFileSystemChildrenWithMetadataTrait<GMetadata extends IFileSystemMetadata> {
  childrenWithMetadata: IFileSystemChildrenWithMetadataFunction<GMetadata>;
}
