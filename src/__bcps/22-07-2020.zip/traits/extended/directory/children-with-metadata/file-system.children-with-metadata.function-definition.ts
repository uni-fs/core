import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { IFileSystemMetadata } from '../../../core/entry/metadata/file-system-metadata.type';
import { IFileSystemEntryWithMetadata } from './file-system-entry-with-metadata.type';

export type IFileSystemChildrenWithMetadataFunctionNotifications<GMetadata extends IFileSystemMetadata> = IDefaultNotificationsUnion<IFileSystemEntryWithMetadata<GMetadata>>;

/**
 * Returns the list of the children of a directory
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a directory, throws an ENTITY_IS_NOT_A_DIRECTORY error
 * @return an Observable revolved with the list of children (as URLs)
 */
export interface IFileSystemChildrenWithMetadataFunction<GMetadata extends IFileSystemMetadata> {
  (
    url: URL,
  ): IObservable<IFileSystemChildrenWithMetadataFunctionNotifications<GMetadata>>;
}



