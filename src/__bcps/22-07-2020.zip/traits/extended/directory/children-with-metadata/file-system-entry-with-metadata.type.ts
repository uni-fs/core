import { IFileSystemMetadata } from '../../../core/entry/metadata/file-system-metadata.type';

export interface IFileSystemEntryWithMetadata<GMetadata extends IFileSystemMetadata> {
  url: URL;
  metadata: GMetadata;
}
