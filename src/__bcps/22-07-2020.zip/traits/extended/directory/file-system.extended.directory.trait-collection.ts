import { IFileSystemMetadata } from '../../core/entry/metadata/file-system-metadata.type';
import { IFileSystemChildrenWithMetadataTrait } from './children-with-metadata/file-system.children-with-metadata.trait';

export interface IFileSystemExtendedDirectoryTraitCollectionConfig {
  metadata: IFileSystemMetadata;
}

export interface IFileSystemExtendedDirectoryTraitCollection<GConfig extends IFileSystemExtendedDirectoryTraitCollectionConfig> extends //
  IFileSystemChildrenWithMetadataTrait<GConfig['metadata']>
//
{
}

