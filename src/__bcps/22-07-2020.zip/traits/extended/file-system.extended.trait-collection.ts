import { IFileSystemCoreTraitCollection, IFileSystemCoreTraitCollectionConfig } from '../core/file-system.core.trait-collection';
import {
  IFileSystemExtendedDirectoryTraitCollection,
  IFileSystemExtendedDirectoryTraitCollectionConfig,
} from './directory/file-system.extended.directory.trait-collection';
import { IFileSystemExtendedFileTraitCollection } from './file/file-system.extended.file.trait-collection';

export interface IFileSystemExtendedTraitCollectionConfig extends IFileSystemCoreTraitCollectionConfig, //
  IFileSystemExtendedDirectoryTraitCollectionConfig
//
{
}

export interface IFileSystemExtendedTraitCollection<GConfig extends IFileSystemExtendedTraitCollectionConfig> extends IFileSystemCoreTraitCollection<GConfig>, //
  IFileSystemExtendedDirectoryTraitCollection<GConfig>,
  // IFileSystemExtendedEntryTraitCollection,
  IFileSystemExtendedFileTraitCollection
//
{
}

export type IGenericFileSystemExtendedTraitCollection = IFileSystemExtendedTraitCollection<IFileSystemExtendedTraitCollectionConfig>;


