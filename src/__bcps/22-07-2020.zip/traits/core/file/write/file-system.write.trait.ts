import { IFileSystemWriteFunction } from './file-system.write.function-definition';


export interface IFileSystemWriteTrait {
  write: IFileSystemWriteFunction;
}
