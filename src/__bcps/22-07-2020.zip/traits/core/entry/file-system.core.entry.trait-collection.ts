import { IFileSystemMetadata } from './metadata/file-system-metadata.type';
import { IFileSystemRemoveTrait } from './remove/file-system.remove.trait';
import { IFileSystemMetadataTrait } from './metadata/file-system.metadata.trait';

export interface IFileSystemCoreEntryTraitCollectionConfig {
  metadata: IFileSystemMetadata;
}

export interface IFileSystemCoreEntryTraitCollection<GConfig extends IFileSystemCoreEntryTraitCollectionConfig> extends //
  IFileSystemRemoveTrait,
  IFileSystemMetadataTrait<GConfig['metadata']>
//
{
}

