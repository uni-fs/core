import { IFileSystemMetadata } from './file-system-metadata.type';
import { IFileSystemMetadataFunction } from './file-system.metadata.function-definition';

export interface IFileSystemMetadataTrait<GMetadata extends IFileSystemMetadata> {
  metadata: IFileSystemMetadataFunction<GMetadata>;
}
