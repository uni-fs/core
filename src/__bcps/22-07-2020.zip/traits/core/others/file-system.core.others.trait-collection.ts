import { IFileSystemGetProtocolsTrait } from './get-protocols/file-system.get-protocols.trait';

export interface IFileSystemCoreOthersTraitCollectionConfig {
  protocols: string;
}

export interface IFileSystemCoreOthersTraitCollection<GConfig extends IFileSystemCoreOthersTraitCollectionConfig> extends //
  IFileSystemGetProtocolsTrait<GConfig['protocols']>
//
{
}

