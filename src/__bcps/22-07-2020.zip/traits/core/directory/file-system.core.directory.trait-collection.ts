import { IFileSystemChildrenTrait } from './children/file-system.children.trait';

export interface IFileSystemCoreDirectoryTraitCollection extends //
  IFileSystemChildrenTrait
//
{
}

