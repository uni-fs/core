import { IFileSystemChildrenFunction } from './file-system.children.function-definition';

export interface IFileSystemChildrenTrait {
  children: IFileSystemChildrenFunction;
}
