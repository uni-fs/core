import { IFileSystemCoreDirectoryTraitCollection } from './directory/file-system.core.directory.trait-collection';
import {
  IFileSystemCoreEntryTraitCollection,
  IFileSystemCoreEntryTraitCollectionConfig,
} from './entry/file-system.core.entry.trait-collection';
import { IFileSystemCoreFileTraitCollection } from './file/file-system.core.file.trait-collection';
import {
  IFileSystemCoreOthersTraitCollection,
  IFileSystemCoreOthersTraitCollectionConfig,
} from './others/file-system.core.others.trait-collection';

export interface IFileSystemCoreTraitCollectionConfig extends //
  IFileSystemCoreEntryTraitCollectionConfig,
  IFileSystemCoreOthersTraitCollectionConfig
//
{
}

export interface IFileSystemCoreTraitCollection<GConfig extends IFileSystemCoreTraitCollectionConfig> extends //
  IFileSystemCoreDirectoryTraitCollection,
  IFileSystemCoreEntryTraitCollection<GConfig>,
  IFileSystemCoreFileTraitCollection,
  IFileSystemCoreOthersTraitCollection<GConfig>
//
{
}

export type IGenericFileSystemCoreTraitCollection = IFileSystemCoreTraitCollection<IFileSystemCoreTraitCollectionConfig>;


