export interface INodeJSError extends Error {
  readonly code: string;
}
