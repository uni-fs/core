export const FILE_SYSTEM_ERROR_NAME = 'FileSystemError';

export type IFileSystemErrorName = typeof FILE_SYSTEM_ERROR_NAME;
