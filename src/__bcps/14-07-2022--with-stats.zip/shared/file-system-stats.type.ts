export interface IFileSystemMetadata {
  birthTime: number; // ms
}
