import { IFileSystemTypesFunction } from './file-system.types.function-definition';

export interface IFileSystemTypesTrait {
  types: IFileSystemTypesFunction;
}
