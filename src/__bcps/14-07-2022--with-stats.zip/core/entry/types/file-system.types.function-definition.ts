import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { IFileSystemTypes } from './file-system.types.type';

export type IFileSystemTypesFunctionNextValue = Set<IFileSystemTypes>;
export type IFileSystemTypesFunctionNotifications = IDefaultNotificationsUnion<IFileSystemTypesFunctionNextValue>;

/**
 * Returns the types of an entry:
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  @return types - an Observable resolved with a Set containing the 'types' of the entry
 */
export interface IFileSystemTypesFunction {
  (
    url: URL,
  ): IObservable<IFileSystemTypesFunctionNotifications>;
}



