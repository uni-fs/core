import { IFileSystemRemoveFunction } from './file-system.remove.function-definition';

export interface IFileSystemRemoveTrait {
  remove: IFileSystemRemoveFunction;
}
