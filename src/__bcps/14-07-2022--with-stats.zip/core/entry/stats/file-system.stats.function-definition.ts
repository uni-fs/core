import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { IFileSystemMetadata } from '../../../shared/file-system-metadata.type';

export type IFileSystemStatsFunctionNotifications = IDefaultNotificationsUnion<IFileSystemMetadata>;


/**
 * Returns some information about an entry
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 * @return stats - an Observable resolved with the stats of the entry
 */
export interface IFileSystemStatsFunction {
  (
    url: URL,
  ): IObservable<IFileSystemStatsFunctionNotifications>;
}

