import { IFileSystemStatsFunction } from './file-system.stats.function-definition';

export interface IFileSystemStatsTrait {
  stats: IFileSystemStatsFunction;
}
