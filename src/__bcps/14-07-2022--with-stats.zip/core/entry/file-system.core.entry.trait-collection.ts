import { IFileSystemRemoveTrait } from './remove/file-system.remove.trait';
import { IFileSystemStatsTrait } from './stats/file-system.stats.trait';
import { IFileSystemTypesTrait } from './types/file-system.types.trait';

export interface IFileSystemCoreEntryTraitCollection extends //
  IFileSystemRemoveTrait,
  IFileSystemStatsTrait,
  IFileSystemTypesTrait
//
{
}

