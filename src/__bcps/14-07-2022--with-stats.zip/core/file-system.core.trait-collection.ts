import { IFileSystemCoreEntryTraitCollection } from './entry/file-system.core.entry.trait-collection';
import { IFileSystemCoreOthersTraitCollection } from './others/file-system.core.others.trait-collection';
import { IFileSystemCoreFileTraitCollection } from './file/file-system.core.file.trait-collection';
import { IFileSystemCoreDirectoryTraitCollection } from './directory/file-system.core.directory.trait-collection';

export interface IFileSystemCoreTraitCollection<GProtocols extends string> extends //
  IFileSystemCoreDirectoryTraitCollection,
  IFileSystemCoreEntryTraitCollection,
  IFileSystemCoreFileTraitCollection,
  IFileSystemCoreOthersTraitCollection<GProtocols>
//
{
}

export type IGenericFileSystemCoreTraitCollection = IFileSystemCoreTraitCollection<string>;


