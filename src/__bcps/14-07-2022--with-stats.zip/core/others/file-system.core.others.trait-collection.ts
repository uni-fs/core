import { IFileSystemGetProtocolsTrait } from './get-protocols/file-system.get-protocols.trait';

export interface IFileSystemCoreOthersTraitCollection<GProtocols extends string> extends //
  IFileSystemGetProtocolsTrait<GProtocols>
//
{
}

