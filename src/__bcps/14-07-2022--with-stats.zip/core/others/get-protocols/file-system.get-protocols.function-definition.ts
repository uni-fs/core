export interface IFileSystemGetProtocolsFunction<GProtocols extends string> {
  (): ReadonlySet<GProtocols>;
}

