import { IFileSystemGetProtocolsFunction } from './file-system.get-protocols.function-definition';

export interface IFileSystemGetProtocolsTrait<GProtocols extends string> {
  getProtocols: IFileSystemGetProtocolsFunction<GProtocols>;
}
