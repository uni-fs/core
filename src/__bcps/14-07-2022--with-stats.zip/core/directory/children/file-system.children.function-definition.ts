import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export type IFileSystemChildrenFunctionNotifications = IDefaultNotificationsUnion<URL>;

/**
 * Returns the list of the children of a directory
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a directory, throws an ENTITY_IS_NOT_A_DIRECTORY error
 * @return an Observable revolved with the list of children (as URLs)
 */
export interface IFileSystemChildrenFunction {
  (
    url: URL,
  ): IObservable<IFileSystemChildrenFunctionNotifications>;
}



