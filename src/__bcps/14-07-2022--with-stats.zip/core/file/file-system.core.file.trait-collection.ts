import { IFileSystemReadTrait } from './read/file-system.read.trait';
import { IFileSystemWriteTrait } from './write/file-system.write.trait';

export interface IFileSystemCoreFileTraitCollection extends //
  IFileSystemReadTrait,
  IFileSystemWriteTrait
//
{
}

