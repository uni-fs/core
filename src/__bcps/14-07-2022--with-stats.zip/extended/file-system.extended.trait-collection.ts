import { IFileSystemExtendedFileTraitCollection } from './file/file-system.extended.file.trait-collection';
import { IFileSystemCoreTraitCollection } from '../core/file-system.core.trait-collection';

export interface IFileSystemExtendedTraitCollection<GProtocols extends string> extends IFileSystemCoreTraitCollection<GProtocols>, //
  // IFileSystemExtendedEntryTraitCollection,
  IFileSystemExtendedFileTraitCollection
//
{
}

export type IGenericFileSystemExtendedTraitCollection = IFileSystemExtendedTraitCollection<string>;


