import { IFileSystemCreateFileFunction } from './file-system.create-file.function-definition';

export interface IFileSystemCreateFileTraitCollection {
  createFile: IFileSystemCreateFileFunction;
}
