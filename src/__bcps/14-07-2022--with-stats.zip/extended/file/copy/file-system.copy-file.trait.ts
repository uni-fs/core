import { IFileSystemCopyFileFunction } from './file-system.copy-file.function-definition';

export interface IFileSystemCopyFileTraitCollection {
  copyFile: IFileSystemCopyFileFunction;
}
