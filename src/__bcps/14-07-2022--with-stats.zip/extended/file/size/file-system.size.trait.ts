import { IFileSystemSizeFunction } from './file-system.size.function-definition';

export interface IFileSystemSizeTraitCollection {
  size: IFileSystemSizeFunction;
}
