import { IFileSystemTruncateFunction } from './file-system.truncate.function-definition';

export interface IFileSystemTruncateTraitCollection {
  truncate: IFileSystemTruncateFunction;
}
