import { isProtocolSupported } from './is-protocol-supported';
import { AsyncTask, Abortable, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';

export function ensureUrlIsSupportedAndCastToUrlAsyncTask<GValue extends IAsyncTaskConstraint<GValue>>(
  protocols: ReadonlySet<string>,
  url: URL,
  callback: (url: URL, abortable: Abortable) => IAsyncTaskInput<GValue>,
  abortable: Abortable,
): AsyncTask<GValue> {
  if (isProtocolSupported(protocols, url)) {
    return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<GValue> => {
      return callback(url, abortable);
    }, abortable);
  } else {
    return AsyncTask.error(new Error(`Unsupported protocol: '${url.protocol}'`), abortable);
  }
}



