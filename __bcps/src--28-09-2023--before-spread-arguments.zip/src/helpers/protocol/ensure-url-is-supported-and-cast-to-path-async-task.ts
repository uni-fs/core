import { Path } from '@lifaon/path';
import { urlToPath } from '../url/url-to-path';
import { Abortable, IAsyncTaskInput, AsyncTask } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { ensureUrlIsSupportedAndCastToUrlAsyncTask } from './ensure-url-is-supported-and-cast-to-url-async-task';

export function ensureUrlIsSupportedAndCastToPathAsyncTask<GValue extends IAsyncTaskConstraint<GValue>>(
  protocols: ReadonlySet<string>,
  url: URL,
  callback: (path: Path, abortable: Abortable) => IAsyncTaskInput<GValue>,
  abortable: Abortable,
): AsyncTask<GValue> {
  return ensureUrlIsSupportedAndCastToUrlAsyncTask(
    protocols,
    url,
    (
      url: URL,
      abortable: Abortable,
    ): IAsyncTaskInput<GValue> => {
      return callback(urlToPath(url), abortable);
    },
    abortable,
  );
}
