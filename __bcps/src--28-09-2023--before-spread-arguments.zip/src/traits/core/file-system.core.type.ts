import { IFileSystemGetProtocolsTrait } from './get-protocols/file-system.get-protocols.trait';
import { IFileSystemListTrait } from './list/file-system.list.trait';
import { IFileSystemGetMetadataTrait } from './get-metadata/file-system.get-metadata.trait';
import { IFileSystemReadTrait } from './read/file-system.read.trait';
import { IFileSystemRemoveTrait } from './remove/file-system.remove.trait';
import { IFileSystemWriteTrait } from './write/file-system.write.trait';
import { IFileSystemMetadata } from '../shared/file-system-metadata.type';

export interface IFileSystemCore<GProtocol extends string, GMetadata extends IFileSystemMetadata> extends //
  IFileSystemGetMetadataTrait<GMetadata>,
  IFileSystemGetProtocolsTrait<GProtocol>,
  IFileSystemListTrait<GMetadata>,
  IFileSystemReadTrait,
  IFileSystemRemoveTrait,
  IFileSystemWriteTrait
//
{
}

export type IGenericFileSystemCore = IFileSystemCore<any, any>;


