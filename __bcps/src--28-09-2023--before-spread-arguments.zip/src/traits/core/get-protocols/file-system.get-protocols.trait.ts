import { IFileSystemGetProtocolsFunction } from './file-system.get-protocols.function-definition';

export interface IFileSystemGetProtocolsTrait<GProtocol extends string> {
  readonly getProtocols: IFileSystemGetProtocolsFunction<GProtocol>;
}
