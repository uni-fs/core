export interface IFileSystemGetProtocolsFunction<GProtocol extends string> {
  (): ReadonlySet<GProtocol>;
}

