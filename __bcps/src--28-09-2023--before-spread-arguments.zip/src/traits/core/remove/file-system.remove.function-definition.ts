import { AsyncTask } from '@lirx/async-task';
import { IOptionalAbortableOptions } from '@lirx/async-task';

/**
 * Removes an entry from the filesystem
 *  - if entry doesn't exist, resolves
 *  - if entry is a directory and is not empty, throws a NOT_EMPTY error
 * @return an AsyncTask revolved with the removed entry's URL
 */

export interface IFileSystemRemoveFunction {
  (
    url: URL,
    options?: IFileSystemRemoveOptions,
  ): AsyncTask<URL>;
}

export interface IFileSystemRemoveOptions extends IOptionalAbortableOptions {

}
