import { IFileSystemEntryWithMetadata } from '../../shared/file-system-entry-with-metadata.type';
import { AsyncTask } from '@lirx/async-task';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';
import { IOptionalAbortableOptions } from '@lirx/async-task';

/**
 * Returns a list of entries
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a directory, throws an ENTITY_IS_NOT_A_DIRECTORY error
 * @return an AsyncTask revolved with the list of list (as URLs)
 */
export interface IFileSystemListFunction<GMetadata extends IFileSystemMetadata> {
  (
    url: URL,
    options?: IFileSystemListOptions,
  ): AsyncTask<readonly IFileSystemEntryWithMetadata<GMetadata>[]>;
}

export interface IFileSystemListOptions extends IOptionalAbortableOptions {
  readonly withMetadata?: boolean; // (default: false)
  readonly search?: string;
  // inParents?: readonly URL[]; // (default: [])
}
