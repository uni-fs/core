import { AsyncTask } from '@lirx/async-task';
import { IEnsureAsyncTaskConstrained } from '@lirx/async-task';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';
import { IOptionalAbortableOptions } from '@lirx/async-task';

/**
 * Returns some information about an entry
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 * @return metadata - an AsyncTask resolved with the metadata of the entry
 */
export interface IFileSystemMetadataFunction<GMetadata extends IFileSystemMetadata> {
  (
    url: URL,
    options?: IFileSystemGetMetadataOptions,
  ): AsyncTask<IEnsureAsyncTaskConstrained<GMetadata>>;
}

export interface IFileSystemGetMetadataOptions extends IOptionalAbortableOptions {

}
