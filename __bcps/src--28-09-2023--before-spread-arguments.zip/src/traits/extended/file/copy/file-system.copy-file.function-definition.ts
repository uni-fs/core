import { IGenericFileSystemCore } from '../../../core/file-system.core.type';
import { IOptionalAbortableOptions, AsyncTask } from '@lirx/async-task';

/**
 * Copies a file
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a file, throws an ENTITY_IS_NOT_A_FILE error
 *  @return an AsyncTask revolved with the destination's URL
 */

export interface IFileSystemCopyFileFunction {
  (
    sourceURL: URL,
    destinationURL: URL,
    options?: IFileSystemCopyFileOptions,
  ): AsyncTask<URL>;
}

export interface IFileSystemCopyFileOptions extends IOptionalAbortableOptions {
  readonly destinationFS?: IGenericFileSystemCore;
}

