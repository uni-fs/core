import { getOptimalBufferSize } from '../../../../../helpers/get-optimal-buffer-size';
import { IFileSystemSizeFunction, IFileSystemSizeFileOptions } from '../file-system.size.function-definition';
import { IFileSystemReadFunction } from '../../../../core/read/file-system.read.function-definition';
import { AsyncTask } from '@lirx/async-task';

export function createFileSystemSizeUsingRead(
  read: IFileSystemReadFunction,
): IFileSystemSizeFunction {
  return (
    url: URL,
    options?: IFileSystemSizeFileOptions,
  ): AsyncTask<number> => {
    return fileSystemSizeUsingRead(
      read,
      url,
      options,
    );
  };
}

export function fileSystemSizeUsingRead(
  read: IFileSystemReadFunction,
  url: URL,
  options?: IFileSystemSizeFileOptions,
): AsyncTask<number> {
  // TODO improve
  return read(
    url,
    new Uint8Array(getOptimalBufferSize()),
    options,
  )
    .successful((buffer: Uint8Array) => {
      return buffer.length;
    });
}

