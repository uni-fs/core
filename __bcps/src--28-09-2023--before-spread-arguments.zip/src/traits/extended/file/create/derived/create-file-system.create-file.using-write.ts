import { IFileSystemCreateFileFunction, IFileSystemCreateFileOptions } from '../file-system.create-file.function-definition';
import { IFileSystemWriteFunction } from '../../../../core/write/file-system.write.function-definition';
import { AsyncTask } from '@lirx/async-task';

export function createFileSystemCreateFileUsingWrite(
  write: IFileSystemWriteFunction,
): IFileSystemCreateFileFunction {
  return (
    url: URL,
    options?: IFileSystemCreateFileOptions,
  ): AsyncTask<URL> => {
    return fileSystemCreateFileUsingWrite(
      write,
      url,
      options,
    );
  };
}

export function fileSystemCreateFileUsingWrite(
  write: IFileSystemWriteFunction,
  url: URL,
  options?: IFileSystemCreateFileOptions,
): AsyncTask<URL> {
  return write(
    url,
    new Uint8Array(0),
    {
      ...options,
      truncateMode: 'none',
    },
  )
    .successful((): URL => {
      return url;
    });
}
