import { IFileSystemTruncateFunction, IFileSystemTruncateOptions } from '../file-system.truncate.function-definition';
import { IFileSystemWriteFunction } from '../../../../core/write/file-system.write.function-definition';
import { AsyncTask } from '@lirx/async-task';

export function createFileSystemTruncateUsingWrite(
  write: IFileSystemWriteFunction,
): IFileSystemTruncateFunction {
  return (
    url: URL,
    size: number,
    options?: IFileSystemTruncateOptions,
  ): AsyncTask<number> => {
    return fileSystemTruncateUsingWrite(
      write,
      url,
      size,
      options,
    );
  };
}

export function fileSystemTruncateUsingWrite(
  write: IFileSystemWriteFunction,
  url: URL,
  size: number,
  options?: IFileSystemTruncateOptions,
): AsyncTask<number> {
  return write(
    url,
    new Uint8Array(0),
    {
      ...options,
      start: size,
      truncateMode: 'truncate',
    },
  );
}
