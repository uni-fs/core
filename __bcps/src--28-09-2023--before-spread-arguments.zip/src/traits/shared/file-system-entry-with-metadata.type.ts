import { IFileSystemMetadata } from './file-system-metadata.type';

export interface IFileSystemEntryWithMetadata<GMetadata extends IFileSystemMetadata> {
  readonly url: URL;
  readonly metadata: GMetadata | undefined;
}
