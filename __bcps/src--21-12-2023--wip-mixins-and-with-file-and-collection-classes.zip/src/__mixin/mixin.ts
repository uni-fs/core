export type IMixinResult<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any) | undefined> =
  GBaseClass extends (abstract new (...args: infer GParameters) => infer GInstance)
    ? (
      Omit<GBaseClass, 'new'>
      & {
      new(
        ...args: GParameters
      ): (GInstance & GTrait);
    }
      )
    : {
      new(): GTrait;
    }
  ;

export function mixin<GTrait extends object>(
  trait: GTrait,
): IMixinResult<GTrait, undefined>;
export function mixin<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any)>(
  trait: GTrait,
  baseClass: GBaseClass,
): IMixinResult<GTrait, GBaseClass>;
export function mixin<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any) | undefined>(
  trait: GTrait,
  baseClass?: GBaseClass,
): IMixinResult<GTrait, GBaseClass> {
  const _class: any = baseClass === void 0
    ? class {
    }
    : class extends baseClass {
    };

  Object.assign(_class.prototype, trait);

  return _class;
}


// const a = mixin({
//   read(this: { url: string }): string {
//     return '';
//   },
// }, class {
//   url!: string;
// });
//
// const b = new a();
// b.read();
