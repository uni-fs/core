import { Path } from '@lifaon/path';
import { Abortable } from '@lirx/async-task';
import { NodeJsCollection } from '../collection/implementations/node-js/node-js-collection.class';
import { NodeJsFile } from '../file/implementations/node-js/node-js-file.class';
import { SchemeResolver } from '../scheme-resolver/scheme-resolver.class';

// const path = new Path(__dirname);
const currentDir = new Path(new URL(import.meta.url).pathname).dirnameOrThrow();

async function debugFile() {
  const fileResolver = new SchemeResolver([
    ['file', NodeJsFile],
  ]);

  const uri = currentDir.concat('test.txt').toURL().href;
  const file = fileResolver.resolve(uri);

  console.log(await file.getMetadata({ abortable: Abortable.never }).toPromise());

  const content = await file.read({
    buffer: new Uint8Array(3),
    position: 1,
    abortable: Abortable.never,
  }).toPromise();

  console.log(content);
}

async function debugCollection() {
  const collectionResolver = new SchemeResolver([
    ['file', NodeJsCollection],
  ]);

  const uri = currentDir.dirnameOrThrow().toURL().href;
  const collection = collectionResolver.resolve(uri);

  const content = await collection.read({
    abortable: Abortable.never,
    // first: 1,
    // after: 'file:///home/valentin/code/dev/tests/uni-fs/core/src/__debug/test.txt',
  }).toPromise();

  console.log(content);
}

async function main() {
  // await debugFile();
  await debugCollection();
}

main();
