import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { IEntryMetadata } from '../../../entry/types/entry-metadata.type';

/**
 * Lists the content of paginated data.
 */
export interface IPaginatedListFunction<GItem> {
  (
    options: IPaginatedListOptions,
  ): AsyncTask<IPage<GItem>>;
}

export interface IPaginatedListOptions extends IAbortableOptions {
  readonly total?: boolean;
  readonly first?: number;
  readonly after?: string;
}


export interface IPage<GItem> {
  readonly total: number | undefined;
  readonly endCursor: string;
  readonly hasNextPage: boolean;
  readonly items: readonly IPageItem<GItem>[];
}

export interface IPageItem<GItem> {
  readonly item: GItem;
  readonly cursor: string;
}
