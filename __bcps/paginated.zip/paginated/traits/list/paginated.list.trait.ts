import { IPaginatedListFunction } from './paginated.list.function-definition';

export interface IPaginatedListTrait<GItem> {
  readonly list: IPaginatedListFunction<GItem>;
}
