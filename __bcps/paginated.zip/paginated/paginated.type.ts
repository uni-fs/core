import { IPaginatedListTrait } from './traits/list/paginated.list.trait';

export interface IPaginated<GItem> extends //
  IPaginatedListTrait<GItem>
//
{
}

