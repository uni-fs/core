import { createFileSystemError } from '../create-file-system-error';
import { IFileSystemError } from '../file-system-error.type';

export function createEntityIsNotACollectionFileSystemError(
  url: string,
): IFileSystemError {
  return createFileSystemError({
    code: 'ENTITY_IS_NOT_A_COLLECTION',
    url,
    reason: 'Not a directory',
  });
}
