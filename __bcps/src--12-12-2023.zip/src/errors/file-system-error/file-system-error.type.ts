import { IFileSystemErrorName } from './file-system-error-name.constant';
import { ICustomErrorMessageOptionalOptions, ICustomError } from '@lirx/utils';

export interface IFileSystemErrorProperties {
  readonly url: string;
  readonly code: string;
}

export interface IFileSystemErrorOptions extends IFileSystemErrorProperties, ICustomErrorMessageOptionalOptions {
  readonly reason?: string;
}



export type IFileSystemError = ICustomError<IFileSystemErrorName, IFileSystemErrorProperties>;

