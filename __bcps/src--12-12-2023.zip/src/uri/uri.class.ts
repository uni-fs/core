const URI_SCHEME_REGEXP = new RegExp('^([a-zA-Z](?:[a-zA-Z0-9\\+\\-\\.])*):', 'g');

/**
 * @deprecated
 */
export class URI {
  readonly #scheme: string;
  readonly #authority: URIAuthority | undefined;
  readonly #path: string;
  readonly #query: string | undefined;
  readonly #fragment: string | undefined;

  constructor(
    input: string,
  ) {
    URI_SCHEME_REGEXP.lastIndex = 0;
    const match: RegExpExecArray | null = URI_SCHEME_REGEXP.exec(input);

    if (match === null) {
      throw new Error(`Invalid scheme.`);
    } else {
      this.#scheme = match[1];

      const rest: string = input.slice(match[0].length);
      const hasAuthority: boolean = rest.startsWith('//');

      const url: URL = new URL(
        hasAuthority
          ? `http:${rest}`
          : input,
      );

      this.#authority = hasAuthority
        ? new URIAuthority(
          (
            (url.username === '')
              ? ''
              : `${url.username}${(url.password === '') ? '' : `:${url.password}`}@`
          ) + url.host
        )
        : void 0;

      const query: string = url.search.slice(1);
      const fragment: string = url.hash.slice(1);

      this.#path = hasAuthority
        ? url.pathname.slice(1)
        : url.pathname;

      this.#query = (query === '')
        ? void 0
        : query;

      this.#fragment = (fragment === '')
        ? void 0
        : fragment;
    }
  }

  get scheme(): string {
    return this.#scheme;
  }

  get authority(): URIAuthority | undefined {
    return this.#authority;
  }

  get path(): string {
    return this.#path;
  }

  get query(): string | undefined {
    return this.#query;
  }

  get fragment(): string | undefined {
    return this.#fragment;
  }

  toString(): string {
    return `${this.#scheme}:` +
      ((this.#authority === void 0) ? '' : `//${this.#authority.toString()}`)
      + this.#path
      + ((this.#query === void 0) ? '' : `?${this.#query}`)
      + ((this.#fragment === void 0) ? '' : `#${this.#fragment}`);
  }

}

export class URIAuthority {
  readonly #userinfo: string | undefined;
  readonly #host: string;
  readonly #port: number | undefined;

  constructor(
    input: string,
  ) {

    let url: URL;
    try {
      url = new URL(`http://${input}`);
    } catch {
      throw new Error(`Invalid URIAuthority`);
    }

    if (
      (url.pathname === '/')
      && (url.search === '')
      && (url.hash === '')
    ) {
      this.#userinfo = (url.username === '')
        ? void 0
        : `${url.username}${(url.password === '') ? '' : `:${url.password}`}`;

      this.#host = url.hostname;
      this.#port = (url.username === '')
        ? void 0
        : Number(url.port);
    } else {
      throw new Error(`Invalid URIAuthority`);
    }
  }

  get userinfo(): string | undefined {
    return this.#userinfo;
  }

  get host(): string {
    return this.#host;
  }

  get port(): number | undefined {
    return this.#port;
  }

  toString(): string {
    return ((this.#userinfo === void 0) ? '' : `${this.#userinfo}@`)
      + this.#host
      + ((this.#port === void 0) ? '' : `:${this.#port}`);
  }
}
