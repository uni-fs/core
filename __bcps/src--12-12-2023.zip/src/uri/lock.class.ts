export interface ILockedFunction {
  (): boolean;
}

/**
 * @deprecated
 * @experimental
 */
export class ReadonlyLock {
  static some(
    locks: readonly ReadonlyLock[],
  ): ReadonlyLock {
    return new ReadonlyLock((): boolean => {
      return locks.some(lock => lock.locked);
    });
  }

  static every(
    locks: readonly ReadonlyLock[],
  ): ReadonlyLock {
    return new ReadonlyLock((): boolean => {
      return locks.every(lock => lock.locked);
    });
  }

  readonly #locked: ILockedFunction;

  constructor(
    locked: ILockedFunction,
  ) {
    this.#locked = locked;
  }

  get locked(): boolean {
    return this.#locked();
  }
}

/**
 * @deprecated
 * @experimental
 */
export class Lock extends ReadonlyLock {
  #locked: boolean;

  constructor() {
    super(() => this.#locked);
    this.#locked = false;
  }

  lock(): this {
    this.#locked = true;
    return this;
  }

  unlock(): this {
    this.#locked = false;
    return this;
  }

  asReadonly(): ReadonlyLock {
    return new ReadonlyLock(() => this.#locked);
  }
}



