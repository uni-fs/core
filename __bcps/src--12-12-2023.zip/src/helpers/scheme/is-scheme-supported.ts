import { IURI } from '../../uri/uri.type';

export function isSchemeSupported(
  schemes: ReadonlySet<string>,
  uri: IURI,
): boolean {
  return schemes.has(uri.scheme);
}

