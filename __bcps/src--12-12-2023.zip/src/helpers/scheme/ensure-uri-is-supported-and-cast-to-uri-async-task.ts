import { AsyncTask, Abortable, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { IURI } from '../../uri/uri.type';
import { parseURI } from '../../uri/parse-uri';

export function ensureUriIsSupportedAndCastToUriAsyncTask<GValue extends IAsyncTaskConstraint<GValue>>(
  schemes: ReadonlySet<string>,
  uri: string,
  callback: (uri: IURI, abortable: Abortable) => IAsyncTaskInput<GValue>,
  abortable: Abortable,
): AsyncTask<GValue> {
  return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<GValue> => {
    const _uri: IURI = parseURI(uri);
    if (schemes.has(_uri.scheme)) {
      return callback(_uri, abortable);
    } else {
      throw new Error(`Unsupported scheme: '${_uri.scheme}'`);
    }

  }, abortable);
}



