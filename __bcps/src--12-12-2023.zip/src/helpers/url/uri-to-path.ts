import { Path } from '@lifaon/path';
import { IURI } from '../../uri/uri.type';

/**
 * Converts a URI to a Path
 */
export function uriToPath(
  uri: IURI,
): Path {
  return new Path(
    (/^\/(?:[a-zA-Z]:)([\/]|$)/g).test(uri.path) // for windows drive letter
      ? uri.path.slice(1) // because url.pathname always starts by /, so windows is /c:/abc
      : uri.path
  );
}


