import { IFileSystemTypesSet } from './file-system.types.type';

export interface IFileSystemMetadata {
  readonly types: IFileSystemTypesSet;
  readonly name: string;
  readonly birthTime: number; // ms
}
