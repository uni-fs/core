import { IFileSystemMetadata } from './file-system-metadata.type';

export type IFileSystemEntryWithMetadata<GMetadata extends IFileSystemMetadata> = GMetadata & {
  readonly uri: string;
}
