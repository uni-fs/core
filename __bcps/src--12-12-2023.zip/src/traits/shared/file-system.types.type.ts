// minimum types that the FS must support
// export type IFileSystemTypes =
//   | 'file'
//   | 'directory'
//   | 'root'
//   ;

export type IFileSystemTypes =
  | 'file'
  | 'collection'
  ;

export type IFileSystemTypesSet = ReadonlySet<IFileSystemTypes>;
