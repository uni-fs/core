import { IFileSystemCore } from '../core/file-system.core.type';
import { IFileSystemExtendedFileTraitCollection } from './file/file-system.extended.file.trait-collection';
import { IFileSystemMetadata } from '../shared/file-system-metadata.type';

export interface IFileSystemExtended<GScheme extends string, GMetadata extends IFileSystemMetadata> extends IFileSystemCore<GScheme, GMetadata>, //
  // IFileSystemExtendedEntryTraitCollection,
  IFileSystemExtendedFileTraitCollection
//
{
}

export type IGenericFileSystemExtended = IFileSystemExtended<any, any>;


