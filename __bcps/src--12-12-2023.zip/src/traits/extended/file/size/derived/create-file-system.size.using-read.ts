import { getOptimalBufferSize } from '../../../../../helpers/get-optimal-buffer-size';
import { IFileSystemSizeFunction, IFileSystemSizeFileOptions } from '../file-system.size.function-definition';
import { IFileSystemReadFunction } from '../../../../core/read/file-system.read.function-definition';
import { AsyncTask } from '@lirx/async-task';

export function createFileSystemSizeUsingRead(
  read: IFileSystemReadFunction,
): IFileSystemSizeFunction {
  return (
    options: IFileSystemSizeFileOptions,
  ): AsyncTask<number> => {
    return fileSystemSizeUsingRead(
      read,
      options,
    );
  };
}

export function fileSystemSizeUsingRead(
  read: IFileSystemReadFunction,
  options: IFileSystemSizeFileOptions,
): AsyncTask<number> {
  // TODO improve
  return read({
    ...options,
    buffer: new Uint8Array(getOptimalBufferSize()),
  })
    .successful((buffer: Uint8Array): number => {
      return buffer.length;
    });
}

