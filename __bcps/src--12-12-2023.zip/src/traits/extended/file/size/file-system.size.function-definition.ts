import { AsyncTask, IAbortableOptions } from '@lirx/async-task';

/**
 * Returns the size of a file
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a file, throws an ENTITY_IS_NOT_A_FILE error
 *  @return an AsyncTask revolved with the entry's size
 */

export interface IFileSystemSizeFunction {
  (
    options: IFileSystemSizeFileOptions,
  ): AsyncTask<number>;
}

export interface IFileSystemSizeFileOptions extends IAbortableOptions {
  readonly uri: string;
}
