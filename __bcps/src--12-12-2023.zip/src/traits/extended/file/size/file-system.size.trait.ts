import { IFileSystemSizeFunction } from './file-system.size.function-definition';

export interface IFileSystemSizeTraitCollection {
  readonly size: IFileSystemSizeFunction;
}
