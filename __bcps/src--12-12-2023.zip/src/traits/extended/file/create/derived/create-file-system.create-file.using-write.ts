import { IFileSystemCreateFileFunction, IFileSystemCreateFileOptions } from '../file-system.create-file.function-definition';
import { IFileSystemWriteFunction } from '../../../../core/write/file-system.write.function-definition';
import { AsyncTask } from '@lirx/async-task';
import { noop } from '@lirx/utils';

export function createFileSystemCreateFileUsingWrite(
  write: IFileSystemWriteFunction,
): IFileSystemCreateFileFunction {
  return (
    options: IFileSystemCreateFileOptions,
  ): AsyncTask<void> => {
    return fileSystemCreateFileUsingWrite(
      write,
      options,
    );
  };
}

export function fileSystemCreateFileUsingWrite(
  write: IFileSystemWriteFunction,
  options: IFileSystemCreateFileOptions,
): AsyncTask<void> {
  return write({
    ...options,
    buffer: new Uint8Array(0),
    truncateMode: 'none',
  }).successful(noop);
}
