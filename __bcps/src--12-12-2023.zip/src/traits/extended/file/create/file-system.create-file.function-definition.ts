import { AsyncTask, IAbortableOptions } from '@lirx/async-task';

/**
 * Creates an empty file
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a file, throws an ENTITY_IS_NOT_A_FILE error
 */

export interface IFileSystemCreateFileFunction {
  (
    options: IFileSystemCreateFileOptions,
  ): AsyncTask<void>;
}

export interface IFileSystemCreateFileOptions extends IAbortableOptions {
  readonly uri: string;
}
