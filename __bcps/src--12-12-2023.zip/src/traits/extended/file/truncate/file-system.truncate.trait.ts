import { IFileSystemTruncateFunction } from './file-system.truncate.function-definition';

export interface IFileSystemTruncateTraitCollection {
  readonly truncate: IFileSystemTruncateFunction;
}
