import { IFileSystemTruncateFunction, IFileSystemTruncateOptions } from '../file-system.truncate.function-definition';
import { IFileSystemWriteFunction } from '../../../../core/write/file-system.write.function-definition';
import { AsyncTask } from '@lirx/async-task';

export function createFileSystemTruncateUsingWrite(
  write: IFileSystemWriteFunction,
): IFileSystemTruncateFunction {
  return (
    options: IFileSystemTruncateOptions,
  ): AsyncTask<number> => {
    return fileSystemTruncateUsingWrite(
      write,
      options,
    );
  };
}

export function fileSystemTruncateUsingWrite(
  write: IFileSystemWriteFunction,
  {
    size,
    ...options
  }: IFileSystemTruncateOptions,
): AsyncTask<number> {
  return write({
    ...options,
    buffer: new Uint8Array(0),
    start: size,
    truncateMode: 'truncate',
  });
}
