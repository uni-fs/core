import { AsyncTask, IAbortableOptions } from '@lirx/async-task';

/**
 * Truncates a file
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a file, throws an ENTITY_IS_NOT_A_FILE error
 *  @return an AsyncTask revolved with the file's size
 */

export interface IFileSystemTruncateFunction {
  (
    options: IFileSystemTruncateOptions,
  ): AsyncTask<number>;
}

export interface IFileSystemTruncateOptions extends IAbortableOptions {
  readonly uri: string;
  readonly size: number;
}
