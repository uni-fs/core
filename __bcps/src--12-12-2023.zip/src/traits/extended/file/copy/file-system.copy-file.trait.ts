import { IFileSystemCopyFileFunction } from './file-system.copy-file.function-definition';

export interface IFileSystemCopyFileTraitCollection {
  readonly copyFile: IFileSystemCopyFileFunction;
}
