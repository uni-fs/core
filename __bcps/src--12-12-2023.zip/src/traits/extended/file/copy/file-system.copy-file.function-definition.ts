import { IGenericFileSystemCore } from '../../../core/file-system.core.type';
import { AsyncTask, IAbortableOptions } from '@lirx/async-task';

/**
 * Copies a file
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a file, throws an ENTITY_IS_NOT_A_FILE error
 *  @return an AsyncTask
 */

export interface IFileSystemCopyFileFunction {
  (
    options: IFileSystemCopyFileOptions,
  ): AsyncTask<void>;
}

export interface IFileSystemCopyFileOptions extends IAbortableOptions {
  readonly sourceURI: string;
  readonly destinationURI: string;
  readonly destinationFS?: IGenericFileSystemCore;
}

