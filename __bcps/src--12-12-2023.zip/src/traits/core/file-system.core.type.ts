import { IFileSystemGetSchemesTrait } from './get-schemes/file-system.get-schemes.trait';
import { IFileSystemListTrait } from './list/file-system.list.trait';
import { IFileSystemGetMetadataTrait } from './get-metadata/file-system.get-metadata.trait';
import { IFileSystemReadTrait } from './read/file-system.read.trait';
import { IFileSystemRemoveTrait } from './remove/file-system.remove.trait';
import { IFileSystemWriteTrait } from './write/file-system.write.trait';
import { IFileSystemMetadata } from '../shared/file-system-metadata.type';

export interface IFileSystemCore<GScheme extends string, GMetadata extends IFileSystemMetadata> extends //
  IFileSystemGetMetadataTrait<GMetadata>,
  IFileSystemGetSchemesTrait<GScheme>,
  IFileSystemListTrait<GMetadata>,
  IFileSystemReadTrait,
  IFileSystemRemoveTrait,
  IFileSystemWriteTrait
//
{
}

export type IGenericFileSystemCore = IFileSystemCore<any, any>;


