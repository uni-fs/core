export interface IFileSystemGetSchemesFunction<GScheme extends string> {
  (): ReadonlySet<GScheme>;
}

