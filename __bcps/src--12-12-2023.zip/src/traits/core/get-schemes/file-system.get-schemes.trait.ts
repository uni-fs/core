import { IFileSystemGetSchemesFunction } from './file-system.get-schemes.function-definition';

export interface IFileSystemGetSchemesTrait<GScheme extends string> {
  readonly getSchemes: IFileSystemGetSchemesFunction<GScheme>;
}
