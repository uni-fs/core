import { AsyncTask, IAbortableOptions } from '@lirx/async-task';

/**
 * Removes an entry from the filesystem
 *  - if entry doesn't exist, resolves
 *  - ~~if entry is a collection and is not empty, throws a NOT_EMPTY error~~
 *  - if entry is a collection, removes it.
 * @return an AsyncTask
 */

export interface IFileSystemRemoveFunction {
  (
    options: IFileSystemRemoveOptions,
  ): AsyncTask<void>;
}

export interface IFileSystemRemoveOptions extends IAbortableOptions {
  readonly uri: string;
}
