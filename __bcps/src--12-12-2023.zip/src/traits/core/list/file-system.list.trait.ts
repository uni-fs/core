import { IFileSystemListFunction } from './file-system.list.function-definition';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';

export interface IFileSystemListTrait<GMetadata extends IFileSystemMetadata> {
  readonly list: IFileSystemListFunction<GMetadata>;
}
