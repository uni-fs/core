import { IFileSystemEntryWithMetadata } from '../../shared/file-system-entry-with-metadata.type';
import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';

/**
 * Returns a list of entries
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 *  - if entry is not a collection, throws an ENTITY_IS_NOT_A_COLLECTION error
 * @return an AsyncTask revolved with the list of metadata for this collection
 */
export interface IFileSystemListFunction<GMetadata extends IFileSystemMetadata> {
  (
    options: IFileSystemListOptions,
  ): AsyncTask<readonly IFileSystemEntryWithMetadata<GMetadata>[]>;
}

// export interface IFileSystemListPagination {
//   readonly total: string | undefined;
// }

export interface IFileSystemListOptions extends IAbortableOptions {
  readonly uri: string;
  readonly search?: string;
}
