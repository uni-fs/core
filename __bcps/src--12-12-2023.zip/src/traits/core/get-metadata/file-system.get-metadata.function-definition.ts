import { AsyncTask, IAbortableOptions, IEnsureAsyncTaskConstrained } from '@lirx/async-task';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';

/**
 * Returns some information about an entry
 *  - if entry doesn't exist, throws an ENTITY_DOESNT_EXIST error
 * @return metadata - an AsyncTask resolved with the metadata of the entry
 */
export interface IFileSystemMetadataFunction<GMetadata extends IFileSystemMetadata> {
  (
    options: IFileSystemGetMetadataOptions,
  ): AsyncTask<IEnsureAsyncTaskConstrained<GMetadata>>;
}

export interface IFileSystemGetMetadataOptions extends IAbortableOptions {
  readonly uri: string;
}
