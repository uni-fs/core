import { IFileSystemMetadataFunction } from './file-system.get-metadata.function-definition';
import { IFileSystemMetadata } from '../../shared/file-system-metadata.type';

export interface IFileSystemGetMetadataTrait<GMetadata extends IFileSystemMetadata> {
  readonly getMetadata: IFileSystemMetadataFunction<GMetadata>;
}
